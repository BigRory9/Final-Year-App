package com.example.myapplication;

public class Constants {
    public static String KEY_USERNAME = "username";

}

